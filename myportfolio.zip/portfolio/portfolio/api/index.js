const express = require('express');
const nodemailer = require('nodemailer');
const cors = require('cors');
require('dotenv').config();

const app = express();

// ১. মিডলওয়্যার সেটআপ
app.use(cors());
app.use(express.json());

// ২. ইমেইল পাঠানোর মেইন রুট
app.post('/api', async (req, res) => {
    const { name, email, message } = req.body;

    // ৩. ইমেইল ট্রান্সপোর্টার (জিমেইল ব্যবহার করে)
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    // ৪. ইমেইল কন্টেন্ট
    const mailOptions = {
        from: email,
        to: process.env.EMAIL_USER, // আপনার নিজের ইমেইল
        subject: `New Message from ${name}`,
        text: `You have a new message from your portfolio:\n\nName: ${name}\nEmail: ${email}\nMessage: ${message}`
    };

    try {
        await transporter.sendMail(mailOptions);
        res.status(200).send('Email sent successfully!');
    } catch (error) {
        console.error('Error:', error);
        res.status(500).send('Error sending email: ' + error.message);
    }
});

// ৫. ভেরসেলের জন্য এটিই সবচেয়ে গুরুত্বপূর্ণ
module.exports = app;